# Task 2: PACS unsupervised domain adaptation

This task uses the assignment's transductive PACS protocol. Photo, Art Painting,
and Cartoon are labeled sources; Sketch is available without class labels during
adaptation. Sketch class labels are read only by `evaluate_final.py` after all
source-selected checkpoints have been frozen.

## Dataset and split

The tested archive is the PACS copy referenced by
[Dassl.pytorch](https://github.com/KaiyangZhou/Dassl.pytorch/blob/master/dassl/data/datasets/dg/pacs.py),
Google Drive file ID `1m4X4fROCCXMO0lRLrr6Zz9Vb3974NWhE`. Its ZIP SHA256 is
`0dc9d0176fa27c9b4504e7c2e962aebe6a79ed0c1819b84148786e590f87e102`.
It contains 1,670 Photo, 2,048 Art Painting, 2,344 Cartoon, and 3,929 Sketch
images. The archive is not stored in Git. An image-decode audit found no
unreadable files in this copy.

Extract the ZIP so the domain directories are under a PACS image root, such as
`/content/atml_pacs/pacs/images`. Generate the seed-6304 stratified 80/20 splits:

```bash
python -m shared.make_pacs_protocol \
  --pacs-root /content/atml_pacs/pacs/images \
  --output /content/drive/MyDrive/ATML-PA1/task2_runs/pacs_sketch_seed6304.json
```

The protocol JSON records source image paths and class IDs and the complete
Sketch image list with opaque IDs but no class IDs. The same source split must
be used by Task 3. Keep a copy of the split manifest in the submitted GitHub
repository. Do not use PACS's preexisting train/crossval split files for this
assignment's split.

## Training

From the repository root, train the six locked configurations:

```bash
python -m task2.train --run-id source_only \
  --pacs-root /content/atml_pacs/pacs/images \
  --protocol /content/drive/MyDrive/ATML-PA1/task2_runs/pacs_sketch_seed6304.json \
  --dataset-source 'Dassl PACS ZIP SHA256:0dc9d0176fa27c9b4504e7c2e962aebe6a79ed0c1819b84148786e590f87e102' \
  --output /content/drive/MyDrive/ATML-PA1/task2_runs
```

Replace `source_only` with `dan_1`, `dann`, `cdan`, `dan_0p1`, and `dan_10`
for the other runs. Each run writes `best.pt`, `last.pt`, `history.csv`, a
source-validation summary, and `run.json` in its own directory. A stopped run
can continue from its next source epoch by adding `--resume` to the same
command. Do not delete or overwrite the original checkpoint directories.

The main comparison is Source-only, DAN with MMD weight 1, DANN, and CDAN.
The controlled study reuses DAN weight 1 and adds weights 0.1 and 10. All
methods use the same ResNet-18 initialization, preprocessing, source sampling,
optimizer, epoch budget, BatchNorm-statistics policy, and source-validation
checkpoint rule. Source-only never loads Sketch pixels and its selected
checkpoint is the unchanged ERM baseline for Task 3.

## Final analysis gate

Run `task2.freeze` only after all six runs are complete. It checks the common
initialization, code version, dataset snapshot, and checkpoint hashes before
writing an immutable manifest. Pass that manifest to `task2.evaluate_final`.
This is the only Task 2 script that reads Sketch class labels. It writes the
required comparison, per-class changes, dominant confusions, individual
predictions, and domain-probe results. Run `task2.plot_results` afterwards for
training curves and the MMD-strength plot.

Do not use Sketch-label metrics to select a checkpoint, revise a Task 2
setting, or change any Task 3 method or setting. The PDF report's language,
interpretation, and analysis must be written by the student, as required by
the assignment.
